<?php

include ('Valite.php');
set_time_limit(0);

header('Content-type:text/html; charset=utf-8');
$posturl = $referer = 'http://code1.myclover.org/Match.aspx';
$imgurl = 'http://code1.myclover.org/Code.aspx';
$cookie = dirname(__FILE__).'/cookie.txt';
$useragent = 'Mozilla/5.0 (Windows NT 6.1; rv:20.0) Gecko/20100101 Firefox/20.0';


$time1 = time();


for($i = 0; $i < 30; $i++)
{
    //循环提交验证码
    submit();
}

//输出执行时间
$time2 = time();
$time = $time2 - $time1;
echo 'time:'.$time;


//提交验证码
function submit()
{
    global $posturl, $referer, $cookie, $useragent;

    //获取隐藏域字符串和验证码构造参数
    $hidden = get_hidden_string('sumit');
    $post = array(
        '__VIEWSTATE' => $hidden['__VIEWSTATE'],
        '__EVENTVALIDATION' => $hidden['__EVENTVALIDATION'],
        'Button1' => 'SUBMIT',
        'TextBox1' => get_code(),
    );

    $curl = curl_init($posturl);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_REFERER, $referer);
    curl_setopt($curl, CURLOPT_USERAGENT, $useragent);
    curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie);
    curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post));
    $src = curl_exec($curl);
    curl_close($curl);
    echo $src;
}


//返回隐藏域的字符串
function get_hidden_string($type)
{
    global $posturl, $cookie, $useragent;

    $url = $posturl;
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_USERAGENT, $useragent);
    curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie);
    curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie);
    $src = curl_exec($curl);
    curl_close($curl);

    preg_match_all('|value=\"(.*)\"|U', $src, $res);
    $ret = array(
        '__VIEWSTATE' => $res[1][0],
        '__EVENTVALIDATION' => $res[1][1],
    );
    return $ret;
}


//返回验证码数字
function get_code()
{
    global $imgurl, $referer, $cookie, $useragent;

    $curl = curl_init($imgurl);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_REFERER, $referer);
    curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie);
    curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie);
    $src = curl_exec($curl);
    curl_close($curl);

    //保存图片
    $fp = fopen('valid.gif', 'wb');
    fwrite($fp, $src);
    fclose($fp);

    //识别验证码图片
    $valid = new Valite();
    $valid->setImage('valid.gif');
    $valid->getHec();
    $validCode = $valid->run();

    return $validCode;
}

?>
