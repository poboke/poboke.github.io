<?php

header('Content-type:text/html; charset=utf-8');
$cookie = dirname(__FILE__).'/cookie.txt';
$useragent = 'Mozilla/5.0 (Windows NT 6.1; rv:20.0) Gecko/20100101 Firefox/20.0';


go();
copy("cookie.txt", "cookie2.txt");    //复制cookie文件


//点击首页go按钮
function go()
{
    global $cookie, $useragent;

    $hidden = get_hidden_string('go');
    $post = array(
        '__VIEWSTATE' => $hidden['__VIEWSTATE'],
        '__EVENTVALIDATION' => $hidden['__EVENTVALIDATION'],
        'Button1' => 'Go!',
    );

    $url = $referer = 'http://code1.myclover.org/Default.aspx';
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_NOBODY, 1);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_REFERER, $referer);
    curl_setopt($curl, CURLOPT_USERAGENT, $useragent);
    curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie);
    curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post));
    $src = curl_exec($curl);
    curl_close($curl);
    echo $src;
}


//返回隐藏域的字符串
function get_hidden_string($type)
{
    global $cookie, $useragent;

    $url = $referer = 'http://code1.myclover.org/Default.aspx';
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_USERAGENT, $useragent);
    curl_setopt($curl, CURLOPT_COOKIEFILE, $cookie);
    curl_setopt($curl, CURLOPT_COOKIEJAR, $cookie);
    $src = curl_exec($curl);
    curl_close($curl);

    preg_match_all('|value=\"(.*)\"|U', $src, $res);
    $ret = array(
        '__VIEWSTATE' => $res[1][0],
        '__EVENTVALIDATION' => $res[1][1],
    );
    return $ret;
}


?>
