<?php

define('WORD_WIDTH',5);
define('WORD_HIGHT',8);
define('OFFSET_X',17);
define('OFFSET_Y',3);
define('WORD_SPACING',10);

class valite
{
	public function setImage($Image)
	{
		$this->ImagePath = $Image;
	}
	
	public function getData()
	{
		return $data;
	}
	
	public function getResult()
	{
		return $DataArray;
	}
	
	public function setRes($res)
	{
		$this->res = $res;
	}

	public function getHec()
	{
        $res = imagecreatefromgif($this->ImagePath);
        $size = getimagesize($this->ImagePath);
		$data = array();
		for($i = 0; $i < $size[1]; ++$i)
		{
			for($j = 0; $j < $size[0]; ++$j)
			{
				$rgb = imagecolorat($res,$j,$i);
				$rgbarray = imagecolorsforindex($res, $rgb);
				if($rgbarray['red'] ==0 || $rgbarray['green'] ==0 || $rgbarray['blue'] ==0)
				{
					$data[$i][$j]=1;
				}else{
					$data[$i][$j]=0;
				}
			}
		}
		$this->DataArray = $data;
		$this->ImageSize = $size;
	}
	
	public function run()
	{
		$result = "";
		$data = array("","","","");
		
		for($i = 0; $i < 4; ++$i)
		{
			$x = ($i * (WORD_WIDTH + WORD_SPACING)) + OFFSET_X;
			$y = OFFSET_Y;
			for($h = $y; $h < (OFFSET_Y + WORD_HIGHT); ++$h)
			{
				for($w = $x; $w < ($x + WORD_WIDTH); ++$w)
				{
					$data[$i] .= $this->DataArray[$h][$w];
				}
			}
		}


		foreach($data as $numKey => $numString)
		{
			$max = 0.0;
			$num = 0;
			foreach($this->Keys as $key => $value)
			{
				$percent = 0.0;
				similar_text($value, $numString, $percent);
				if(intval($percent) > $max)
				{
					$max = $percent;
					$num = $key;
					if(intval($percent) > 95)
						break;
				}
			}
			$result .= $num;
		}
		$this->data = $result;

		return $result;
	}

	public function Draw()
	{
		for($i = 0; $i < $this->ImageSize[1]; ++$i)
		{
	        for($j = 0; $j < $this->ImageSize[0]; ++$j)
		    {
			    echo $this->DataArray[$i][$j];
	        }
		    echo "\n";
		}
	}
	
	public function __construct()
	{
		$this->Keys = array(
			'0'=>'0111011011110111101111011110111101101110',
			'1'=>'0011001110111101011000110001100011000110',
			'2'=>'0111011011000110001100110011001100011111',
			'3'=>'0111011011000110011000011000111101101110',
			'4'=>'0001100111010110101110011111110001100011',
			'5'=>'0111101100110001111010011000111101101110',
			'6'=>'0111011011110001111011011110111101101110',
			'7'=>'1111100011001100011001100011000110001100',
			'8'=>'0111011011110110111011011110111101101110',
			'9'=>'0111011011110111101101111000111101101110',
		);
	}
	
	protected $ImagePath;
	protected $DataArray;
	protected $ImageSize;
	protected $data;
	protected $Keys;
	protected $NumStringArray;
	protected $res;
}
?>
