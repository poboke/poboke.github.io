<?php

include ('Valite.php');
echo "<img src='v1.jpg' /><br>";

$valid = new Valite();
$valid->setImage("v1.jpg");
$valid->getHec();
$validCode = $valid->run();
echo $validCode;

?>